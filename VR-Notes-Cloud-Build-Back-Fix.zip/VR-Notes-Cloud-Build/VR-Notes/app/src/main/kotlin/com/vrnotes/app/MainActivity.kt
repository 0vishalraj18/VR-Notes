package com.vrnotes.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val backStack = java.util.ArrayDeque<() -> Unit>()
    private val blue = Color.rgb(25,118,210)
    private val dark = Color.rgb(7,17,31)

    private val branches = listOf(
        "🏗️ Civil Engineering (322)",
        "⚙️ Mechanical Engineering – Production (343)",
        "🚗 Mechanical Engineering – Automobile (341)",
        "⚡ Electrical Engineering (328)",
        "📡 Electronics & Communication Engineering (361)",
        "💻 Computer Science & Engineering (355)"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    override fun onBackPressed() {
        if (backStack.isNotEmpty()) {
            val previous = backStack.removeLast()
            previous()
        } else {
            super.onBackPressed()
        }
    }

    private fun openScreen(previous: () -> Unit, next: () -> Unit) {
        backStack.addLast(previous)
        next()
    }

    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(dark)
        }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 40f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(8, 0, 8, 4)
            setOnClickListener { onBackPressed() }
        }
        val titleView = TextView(this).apply {
            text = title
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(58), -1))
        bar.addView(titleView, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(64)))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showHome() {
        setup("VR Notes")
        val content = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
        val logo = ImageView(this).apply {
            setImageResource(com.vrnotes.app.R.drawable.vr_notes_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        content.addView(logo, LinearLayout.LayoutParams(-1, dp(190)))
        addHeading(content, "📚 Study Material")
        branches.forEachIndexed { i, name ->
            addButton(content, name) { openScreen({ showHome() }, { showSemesters(i, name) }) }
        }
        addButton(content, "⚙️ Settings") { openScreen({ showHome() }, { showSettings() }) }
    }

    private fun showSemesters(branchIndex: Int, branchName: String) {
        setup(branchName)
        val content = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
        addHeading(content, "Select Semester")
        (1..6).forEach { sem ->
            addButton(content, "📘 Semester $sem") { openScreen({ showSemesters(branchIndex, branchName) }, { showSubjects(branchIndex, sem) }) }
        }
    }

    private fun showSubjects(branchIndex: Int, sem: Int) {
        setup("Semester $sem")
        val content = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
        addHeading(content, "Subjects")
        val subjects = listOf("Subject 1", "Subject 2", "Subject 3", "Subject 4", "Subject 5")
        subjects.forEachIndexed { index, subject ->
            addButton(content, "📖 $subject") { openScreen({ showSubjects(branchIndex, sem) }, { showUnits(sem, index + 1, subject) }) }
        }
    }

    private fun showUnits(sem: Int, subjectIndex: Int, subject: String) {
        setup(subject)
        val content = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
        addHeading(content, "Units")
        (1..5).forEach { unit ->
            addButton(content, "📑 Unit $unit") { openScreen({ showUnits(sem, subjectIndex, subject) }, { showUnit(unit, subject) }) }
        }
        addButton(content, "⭐ Important PYQ") { openScreen({ showUnits(sem, subjectIndex, subject) }, { showPyq(subject) }) }
    }

    private fun showUnit(unit: Int, subject: String) {
        setup("Unit $unit")
        val content = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
        addHeading(content, "$subject • Unit $unit")
        addInfo(content, "📚 Study material will appear here.")
        addButton(content, "📄 Open PDF Material") {
            Toast.makeText(this, "PDF link will be added here.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPyq(subject: String) {
        setup("Important PYQ")
        val content = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
        addHeading(content, "⭐ $subject")
        addInfo(content, "Important previous-year questions will appear here.")
        addButton(content, "📄 Open PYQ PDF") {
            Toast.makeText(this, "PYQ PDF link will be added here.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSettings() {
        setup("Settings")
        val content = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
        addButton(content, "ℹ️ About VR Notes") {
            showMessage("VR Notes", "Diploma students ke liye study material, syllabus, units aur important PYQ app.")
        }
        addButton(content, "📞 Contact") {
            showMessage("Contact", "Yahan baad mein contact details add ki ja sakti hain.")
        }
    }

    private fun addHeading(parent: LinearLayout, text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 20f
            setTextColor(dark)
            setTypeface(null, Typeface.BOLD)
            setPadding(4, 8, 4, 14)
        }
        parent.addView(tv)
    }

    private fun addInfo(parent: LinearLayout, text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 17f
            setTextColor(Color.DKGRAY)
            setPadding(8, 16, 8, 24)
        }
        parent.addView(tv)
    }

    private fun addButton(parent: LinearLayout, text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(dark)
            setOnClickListener { action() }
            background = GradientDrawable().apply {
                setColor(Color.rgb(244,248,252))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.rgb(210,220,230))
            }
            stateListAnimator = null
            isAllCaps = false
        }
        val lp = LinearLayout.LayoutParams(-1, dp(58))
        lp.setMargins(0, 0, 0, dp(10))
        parent.addView(b, lp)
    }

    private fun showMessage(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("OK", null).show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

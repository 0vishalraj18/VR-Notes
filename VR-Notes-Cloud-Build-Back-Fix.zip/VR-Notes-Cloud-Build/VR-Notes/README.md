# VR Notes Android App

Starter Android Studio project for the VR Notes study-material app.

Included:
- VR Notes logo
- Home screen
- 6 engineering branches
- Semester 1–6 navigation
- Subject navigation
- Unit 1–5 navigation
- Important PYQ screen
- Settings: About + Contact
- Placeholder PDF/Google Drive material buttons

Open the VR-Notes folder in Android Studio, sync Gradle, and run on an Android phone/emulator.

Next step: replace placeholder subject/unit names and PDF buttons with the real study material and Google Drive links.

# VR Notes — Cloud APK Build

This project can be built on GitHub Actions, so you do not need a laptop or Android Studio.

## Files
- `VR-Notes/` — Android project

## GitHub Actions workflow
Create `.github/workflows/build-apk.yml` in your GitHub repository and paste:

```yaml
name: Build VR Notes APK

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v6

      - name: Set up Java
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4

      - name: Build debug APK
        working-directory: VR-Notes
        run: gradle :app:assembleDebug --no-daemon

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: VR-Notes-debug-apk
          path: VR-Notes/app/build/outputs/apk/debug/app-debug.apk
```

After the workflow finishes, open the workflow run and download the `VR-Notes-debug-apk` artifact.
